require 'dependencies'
require 'uri_translator'
